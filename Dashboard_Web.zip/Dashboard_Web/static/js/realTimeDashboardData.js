function autoRefresh(){
    setInterval(function(){
        location.reload();
    }, 60000); // tempo em milisegundos
}
